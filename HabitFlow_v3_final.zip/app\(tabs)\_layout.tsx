import { Tabs } from "expo-router";
import { StyleSheet, View, Text } from "react-native";
import { useTheme } from "../../src/context/ThemeContext";

function TabIcon({ emoji, label, focused }: { emoji: string; label: string; focused: boolean }) {
  const { colors } = useTheme();
  return (
    <View style={tab.wrap}>
      <Text style={tab.emoji}>{emoji}</Text>
      <Text style={[tab.label, focused && { color: colors.primary }]}>{label}</Text>
      {focused && (
        <View style={[tab.dot, { backgroundColor: colors.primary }]} />
      )}
    </View>
  );
}

export default function TabsLayout() {
  const { colors } = useTheme();

  return (
    <Tabs
      screenOptions={{
        headerShown: false,
        tabBarStyle: {
          backgroundColor: colors.tabBar,
          borderTopColor:  colors.cardBorder,
          borderTopWidth:  1,
          height: 70,
          paddingBottom: 10,
        },
        tabBarShowLabel: false,
      }}
    >
      <Tabs.Screen
        name="index"
        options={{ tabBarIcon: ({ focused }) => <TabIcon emoji="🏠" label="Hoy" focused={focused} /> }}
      />
      <Tabs.Screen
        name="habits"
        options={{ tabBarIcon: ({ focused }) => <TabIcon emoji="📋" label="Hábitos" focused={focused} /> }}
      />
      <Tabs.Screen
        name="streaks"
        options={{ tabBarIcon: ({ focused }) => <TabIcon emoji="🔥" label="Rachas" focused={focused} /> }}
      />
      <Tabs.Screen
        name="profile"
        options={{ tabBarIcon: ({ focused }) => <TabIcon emoji="👤" label="Perfil" focused={focused} /> }}
      />
    </Tabs>
  );
}

const tab = StyleSheet.create({
  wrap:  { alignItems: "center", paddingTop: 6 },
  emoji: { fontSize: 22 },
  label: { color: "#A0A0B2", fontSize: 10, marginTop: 2 },
  dot:   { width: 4, height: 4, borderRadius: 2, marginTop: 3 },
});
