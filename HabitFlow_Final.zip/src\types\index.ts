import type { Timestamp } from "firebase/firestore";

// ══════════════════════════════════════════════════════════════════════════════
// MVT — ARQUITECTURA MODELO-VISTA-TEMPLATE
// ──────────────────────────────────────────────────────────────────────────────
// MODEL    → src/models/       (entidades de dominio, validadores, factories)
// VIEW     → app/              (pantallas de Expo Router — la "Vista" en MVT)
// TEMPLATE → src/templates/   (componentes reutilizables de UI)
//
// Este archivo actúa como puente de tipos compartidos entre las tres capas.
// Los Contexts en src/context/ actúan como ViewModel (estado + lógica de negocio).
// ══════════════════════════════════════════════════════════════════════════════

// ─── Sensor Types ─────────────────────────────────────────────────────────────
export type SensorType = "camera" | "accelerometer" | "gyroscope" | "location" | "manual";

// ─── Habit ───────────────────────────────────────────────────────────────────
export interface Habit {
  id:          string;
  userId:      string;
  name:        string;
  emoji:       string;
  color:       string;
  target:      number;
  unit:        string;
  description: string;
  sensorType:  SensorType;
  isActive:    boolean;
  createdAt:   Timestamp;
}

export type HabitFormData = Omit<Habit, "id" | "userId" | "createdAt" | "isActive">;

// ─── Daily Log ────────────────────────────────────────────────────────────────
export interface DailyLog {
  habitId:     string;
  date:        string;      // YYYY-MM-DD
  current:     number;
  completed:   boolean;
  completedAt: Timestamp | null;
  updatedAt:   Timestamp;
  photoUri?:   string;      // URI de foto (hábitos tipo "camera")
}

// ─── Streak ───────────────────────────────────────────────────────────────────
export interface StreakData {
  habitId:           string;
  currentStreak:     number;
  longestStreak:     number;
  lastCompletedDate: string | null;
  totalCompletions:  number;
  updatedAt:         Timestamp;
}

// ─── User Profile ─────────────────────────────────────────────────────────────
export interface UserProfile {
  uid:         string;
  email:       string | null;
  displayName: string | null;
  photoURL:    string | null;
  isAnonymous: boolean;
}

// ─── Sensor Readings ─────────────────────────────────────────────────────────
export interface SensorReadings {
  photosToday:    number;
  lastPhotoUri:   string | null;
  activityScore:  number;
  minutesFlipped: number;
  distanceMeters: number;
}

// ─── Context Value (ViewModel) ────────────────────────────────────────────────
export interface HabitsContextValue {
  habits:    Habit[];
  todayLogs: Record<string, DailyLog>;
  streaks:   Record<string, StreakData>;
  isLoading: boolean;
  readings:  SensorReadings;
  takePhoto: (habitId?: string) => Promise<void>;
  addHabit:       (data: HabitFormData) => Promise<void>;
  updateHabit:    (id: string, data: Partial<HabitFormData>) => Promise<void>;
  deleteHabit:    (id: string) => Promise<void>;
  manualComplete: (habitId: string) => Promise<void>;
  manualIncrement:(habitId: string) => Promise<void>;
}
