import {
  collection, doc, getDocs, addDoc, updateDoc,
  serverTimestamp, query, where,
} from "firebase/firestore";
import { db } from "./firebase";
import type { Habit, HabitFormData } from "../types";

// ── MVT: MODEL — Capa de acceso a datos para la entidad Habit ─────────────────
function habitsCol(userId: string) {
  return collection(db, "users", userId, "habits");
}

// ─── Read all active habits (sin índice compuesto — ordena en memoria) ────────
export async function fetchHabits(userId: string): Promise<Habit[]> {
  try {
    // Solo filtramos por isActive para evitar requerir índice compuesto Firestore.
    // El orderBy("createdAt") se aplica en memoria después de la lectura.
    const q = query(habitsCol(userId), where("isActive", "==", true));
    const snap = await getDocs(q);
    const habits = snap.docs.map((d) => ({ id: d.id, ...d.data() } as Habit));
    // Ordenar por createdAt ascendente en memoria
    return habits.sort((a, b) => {
      const ta = (a.createdAt as any)?.toMillis?.() ?? 0;
      const tb = (b.createdAt as any)?.toMillis?.() ?? 0;
      return ta - tb;
    });
  } catch (e) {
    console.error("[habitsService] fetchHabits:", e);
    return [];
  }
}

// ─── Add habit ────────────────────────────────────────────────────────────────
export async function addHabit(userId: string, data: HabitFormData): Promise<string> {
  const ref = await addDoc(habitsCol(userId), {
    ...data,
    userId,
    isActive:  true,
    createdAt: serverTimestamp(),
  });
  return ref.id;
}

// ─── Update habit ─────────────────────────────────────────────────────────────
export async function updateHabit(
  userId: string,
  habitId: string,
  data: Partial<HabitFormData>
): Promise<void> {
  await updateDoc(doc(habitsCol(userId), habitId), data);
}

// ─── Soft delete (mark inactive) ─────────────────────────────────────────────
export async function deleteHabit(userId: string, habitId: string): Promise<void> {
  await updateDoc(doc(habitsCol(userId), habitId), { isActive: false });
}
