/**
 * MVT — CAPA TEMPLATE
 * src/templates/ui/SectionHeader.tsx
 *
 * Header de sección reutilizable: título + badge opcional.
 */
import React from "react";
import { View, Text, StyleSheet, ViewStyle } from "react-native";
import { colors, typography } from "../../utils/theme";

interface SectionHeaderProps {
  title:       string;
  badge?:      string | number;
  style?:      ViewStyle;
}

export function SectionHeader({ title, badge, style }: SectionHeaderProps) {
  return (
    <View style={[styles.row, style]}>
      <Text style={styles.title}>{title}</Text>
      {badge !== undefined && (
        <View style={styles.badge}>
          <Text style={styles.badgeText}>{badge}</Text>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  row: {
    flexDirection:  "row",
    alignItems:     "center",
    gap:            8,
    marginBottom:   12,
    paddingHorizontal: 16,
  },
  title: {
    ...typography.sm,
    color:         colors.muted,
    letterSpacing: 1,
    textTransform: "uppercase",
    fontWeight:    "700",
    flex:          1,
  },
  badge: {
    backgroundColor: `${colors.primary}30`,
    borderRadius:    99,
    paddingHorizontal: 8,
    paddingVertical: 2,
  },
  badgeText: {
    color:     colors.primary,
    fontSize:  11,
    fontWeight: "700",
  },
});
