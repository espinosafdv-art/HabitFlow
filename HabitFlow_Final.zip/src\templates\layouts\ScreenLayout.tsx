/**
 * MVT — CAPA TEMPLATE
 * src/templates/layouts/ScreenLayout.tsx
 *
 * Layout base para todas las pantallas. Aplica el fondo del tema,
 * SafeArea y un padding consistente de 8px grid.
 */
import React from "react";
import { View, StyleSheet, ViewStyle, ScrollView } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { colors } from "../../utils/theme";

interface ScreenLayoutProps {
  children:    React.ReactNode;
  scrollable?: boolean;
  style?:      ViewStyle;
  /** Si true, aplica paddingTop con el inset de notch */
  safeTop?:    boolean;
}

export function ScreenLayout({
  children,
  scrollable = false,
  style,
  safeTop = false,
}: ScreenLayoutProps) {
  const insets = useSafeAreaInsets();

  const containerStyle: ViewStyle = {
    ...styles.container,
    paddingTop:    safeTop ? insets.top : 0,
    paddingBottom: insets.bottom,
    ...style,
  };

  if (scrollable) {
    return (
      <View style={containerStyle}>
        <ScrollView
          showsVerticalScrollIndicator={false}
          contentContainerStyle={styles.scrollContent}
        >
          {children}
        </ScrollView>
      </View>
    );
  }

  return <View style={containerStyle}>{children}</View>;
}

const styles = StyleSheet.create({
  container: {
    flex:            1,
    backgroundColor: colors.bg,
  },
  scrollContent: {
    paddingBottom: 32,
  },
});
