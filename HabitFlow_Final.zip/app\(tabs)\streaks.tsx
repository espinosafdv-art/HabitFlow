import React from "react";
import { View, Text, ScrollView, ActivityIndicator, StyleSheet } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useHabits }  from "../../src/context/HabitsContext";
import { useTheme }   from "../../src/context/ThemeContext";
import { StreakBadge } from "../../src/components/StreakBadge";
import { radii }       from "../../src/utils/theme";

export default function StreaksScreen() {
  const insets   = useSafeAreaInsets();
  const { colors } = useTheme();
  const { habits, streaks, isLoading } = useHabits();
  const sortedHabits     = [...habits].sort((a, b) => (streaks[b.id]?.currentStreak ?? 0) - (streaks[a.id]?.currentStreak ?? 0));
  const bestStreak       = Math.max(0, ...Object.values(streaks).map((s) => s.currentStreak));
  const bestLongest      = Math.max(0, ...Object.values(streaks).map((s) => s.longestStreak));
  const totalCompletions = Object.values(streaks).reduce((acc, s) => acc + s.totalCompletions, 0);
  const activeStreaks     = Object.values(streaks).filter((s) => s.currentStreak > 0).length;
  if (isLoading) return <View style={{ flex: 1, backgroundColor: colors.bg, justifyContent: "center", alignItems: "center" }}><ActivityIndicator size="large" color={colors.primary} /></View>;
  return (
    <View style={{ flex: 1, backgroundColor: colors.bg, paddingBottom: insets.bottom }}>
      <View style={[styles.header, { paddingTop: insets.top + 16, backgroundColor: colors.card, borderBottomColor: colors.cardBorder }]}>
        <View style={[styles.headerAccent, { backgroundColor: colors.warning }]} />
        <Text style={[styles.title, { color: colors.text }]}>\uD83D\uDD25 Rachas</Text>
        <Text style={[styles.subtitle, { color: colors.subtext }]}>Tu historial de constancia</Text>
      </View>
      <ScrollView showsVerticalScrollIndicator={false}>
        <View style={styles.statsGrid}>
          {[{label:"Mejor racha activa",value:bestStreak,emoji:"\uD83D\uDD25"},{label:"Racha más larga",value:bestLongest,emoji:"\uD83C\uDFC6"},{label:"Rachas activas",value:activeStreaks,emoji:"\u26A1"},{label:"Total completados",value:totalCompletions,emoji:"\u2705"}].map((s) => (
            <View key={s.label} style={[styles.statCard, { backgroundColor: colors.card, borderColor: colors.cardBorder }]}>
              <Text style={{ fontSize: 24 }}>{s.emoji}</Text>
              <Text style={[styles.statValue, { color: colors.text }]}>{s.value}</Text>
              <Text style={[styles.statLabel, { color: colors.subtext }]}>{s.label}</Text>
            </View>
          ))}
        </View>
        {habits.length === 0 && <View style={styles.empty}><Text style={{ fontSize: 48 }}>\uD83D\uDD25</Text><Text style={[{ fontSize: 20, fontWeight: "700", marginTop: 12 }, { color: colors.text }]}>Sin rachas todavía</Text><Text style={[{ fontSize: 13, textAlign: "center", paddingHorizontal: 32, marginTop: 6 }, { color: colors.subtext }]}>Completa hábitos diariamente para construir rachas</Text></View>}
        <View style={{ paddingHorizontal: 16, paddingBottom: 32 }}>
          <Text style={[styles.sectionTitle, { color: colors.text }]}>Por hábito</Text>
          {sortedHabits.map((habit) => {
            const streak = streaks[habit.id];
            if (!streak) return null;
            return (
              <View key={habit.id} style={[styles.habitStreakCard, { backgroundColor: colors.card, borderColor: colors.cardBorder }]}>
                <View style={styles.habitRow}>
                  <View style={[styles.emojiWrap, { backgroundColor: `${habit.color}20` }]}><Text style={{ fontSize: 22 }}>{habit.emoji}</Text></View>
                  <View style={{ flex: 1 }}>
                    <Text style={[{ fontSize: 16, fontWeight: "700" }, { color: colors.text }]}>{habit.name}</Text>
                    <Text style={[{ fontSize: 12 }, { color: colors.subtext }]}>{streak.totalCompletions} completado{streak.totalCompletions !== 1 ? "s" : ""} en total</Text>
                  </View>
                </View>
                <StreakBadge streak={streak} />
                <View style={[styles.motivationBanner, { backgroundColor: `${habit.color}10`, borderColor: `${habit.color}25` }]}>
                  <Text style={[{ fontSize: 13, fontWeight: "500" }, { color: habit.color }]}>
                    {streak.currentStreak === 0 ? "\uD83D\uDCAA ¡Empieza hoy tu racha!" : streak.currentStreak < 3 ? "\uD83C\uDF31 ¡Buen comienzo!" : streak.currentStreak < 7 ? "\uD83D\uDD25 ¡Vas muy bien!" : streak.currentStreak < 30 ? "\u26A1 ¡Increíble constancia!" : "\uD83C\uDFC6 ¡Eres imparable!"}
                  </Text>
                </View>
              </View>
            );
          })}
        </View>
      </ScrollView>
    </View>
  );
}
const styles = StyleSheet.create({
  header:          { paddingHorizontal: 20, paddingBottom: 16, borderBottomWidth: 1, marginBottom: 16 },
  headerAccent:    { position: "absolute", top: 0, left: 0, right: 0, height: 3 },
  title:           { fontSize: 26, fontWeight: "800" },
  subtitle:        { fontSize: 13, marginTop: 2 },
  statsGrid:       { flexDirection: "row", flexWrap: "wrap", paddingHorizontal: 12, gap: 8, marginBottom: 24 },
  statCard:        { flex: 1, minWidth: "46%", borderRadius: radii.lg, borderWidth: 1, padding: 16, alignItems: "center", gap: 4 },
  statValue:       { fontSize: 26, fontWeight: "800" },
  statLabel:       { fontSize: 11, textAlign: "center" },
  sectionTitle:    { fontSize: 16, fontWeight: "700", marginBottom: 12 },
  habitStreakCard: { borderRadius: radii.xl, borderWidth: 1, padding: 16, marginBottom: 16 },
  habitRow:        { flexDirection: "row", alignItems: "center", gap: 12, marginBottom: 12 },
  emojiWrap:       { width: 46, height: 46, borderRadius: 12, alignItems: "center", justifyContent: "center" },
  motivationBanner:{ borderRadius: radii.md, borderWidth: 1, paddingVertical: 8, paddingHorizontal: 12, marginTop: 4 },
  empty:           { alignItems: "center", paddingVertical: 40 },
});
