/**
 * MVT — CAPA TEMPLATE
 * src/templates/ui/EmptyState.tsx
 *
 * Template reutilizable para pantallas sin contenido.
 */
import React from "react";
import { View, Text, StyleSheet, Pressable } from "react-native";
import { colors, radii } from "../../utils/theme";

interface EmptyStateProps {
  emoji:       string;
  title:       string;
  subtitle?:   string;
  actionLabel?: string;
  onAction?:   () => void;
}

export function EmptyState({
  emoji, title, subtitle, actionLabel, onAction,
}: EmptyStateProps) {
  return (
    <View style={styles.container}>
      <Text style={styles.emoji}>{emoji}</Text>
      <Text style={styles.title}>{title}</Text>
      {subtitle && <Text style={styles.subtitle}>{subtitle}</Text>}
      {actionLabel && onAction && (
        <Pressable
          onPress={onAction}
          style={({ pressed }) => [styles.btn, pressed && { opacity: 0.75 }]}
        >
          <Text style={styles.btnText}>{actionLabel}</Text>
        </Pressable>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex:           1,
    alignItems:     "center",
    justifyContent: "center",
    padding:        32,
    gap:            8,
  },
  emoji:    { fontSize: 48, marginBottom: 8 },
  title:    { color: colors.white, fontSize: 18, fontWeight: "700", textAlign: "center" },
  subtitle: { color: colors.muted, fontSize: 14, textAlign: "center", lineHeight: 20 },
  btn: {
    marginTop:       16,
    backgroundColor: colors.primary,
    borderRadius:    radii.md,
    paddingHorizontal: 24,
    paddingVertical:   12,
  },
  btnText: { color: colors.white, fontWeight: "700", fontSize: 14 },
});
