/**
 * MVT — VISTA
 * app/(tabs)/profile.tsx
 *
 * Pantalla de perfil con:
 *  - Foto de perfil editable (cámara / galería)
 *  - Edición de nombre
 *  - Toggle de modo oscuro/claro
 *  - Estadísticas
 *  - Cerrar sesión
 */
import React, { useState } from "react";
import {
  View, Text, Pressable, StyleSheet, Alert, ScrollView,
  Switch, TextInput, Image, ActivityIndicator, KeyboardAvoidingView, Platform,
} from "react-native";
import * as ImagePicker      from "expo-image-picker";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useAuth }           from "../../src/context/AuthContext";
import { useHabits }         from "../../src/context/HabitsContext";
import { useTheme }          from "../../src/context/ThemeContext";
import { radii }             from "../../src/utils/theme";

export default function ProfileScreen() {
  const insets = useSafeAreaInsets();
  const { profile, signOut, updateProfile } = useAuth();
  const { habits, streaks }                  = useHabits();
  const { colors, isDark, toggleTheme }      = useTheme();

  // ── Estado de edición ────────────────────────────────────────────────────
  const [editing,     setEditing]     = useState(false);
  const [newName,     setNewName]     = useState(profile?.displayName ?? "");
  const [localPhoto,  setLocalPhoto]  = useState<string | null>(profile?.photoURL ?? null);
  const [saving,      setSaving]      = useState(false);

  // ── Estadísticas ─────────────────────────────────────────────────────────
  const totalHabits      = habits.length;
  const totalCompletions = Object.values(streaks).reduce((a, s) => a + s.totalCompletions, 0);
  const activeDays       = new Set(
    Object.values(streaks).filter((s) => s.lastCompletedDate).map((s) => s.lastCompletedDate)
  ).size;
  const bestStreak = Math.max(0, ...Object.values(streaks).map((s) => s.longestStreak));

  // ── Cerrar sesión ─────────────────────────────────────────────────────────
  const handleSignOut = () =>
    Alert.alert("Cerrar sesión", "¿Deseas salir de tu cuenta?", [
      { text: "Cancelar", style: "cancel" },
      { text: "Salir", style: "destructive", onPress: async () => { await signOut(); } },
    ]);

  // ── Foto de perfil ────────────────────────────────────────────────────────
  const pickPhoto = async (fromCamera: boolean) => {
    const perm = fromCamera
      ? await ImagePicker.requestCameraPermissionsAsync()
      : await ImagePicker.requestMediaLibraryPermissionsAsync();

    if (perm.status !== "granted") {
      Alert.alert("Permiso requerido", "Necesitamos acceso para seleccionar una foto.");
      return;
    }

    const result = fromCamera
      ? await ImagePicker.launchCameraAsync({ mediaTypes: ["images"], quality: 0.8, allowsEditing: true, aspect: [1, 1] })
      : await ImagePicker.launchImageLibraryAsync({ mediaTypes: ["images"], quality: 0.8, allowsEditing: true, aspect: [1, 1] });

    if (!result.canceled && result.assets[0]) {
      setLocalPhoto(result.assets[0].uri);
    }
  };

  const showPhotoPicker = () => {
    Alert.alert("Foto de perfil", "¿Cómo quieres elegir la foto?", [
      { text: "📷 Cámara",      onPress: () => pickPhoto(true) },
      { text: "🖼️ Galería",     onPress: () => pickPhoto(false) },
      localPhoto ? { text: "🗑️ Eliminar foto", style: "destructive", onPress: () => setLocalPhoto(null) } : null,
      { text: "Cancelar", style: "cancel" },
    ].filter(Boolean) as any);
  };

  // ── Guardar cambios ───────────────────────────────────────────────────────
  const handleSave = async () => {
    if (!newName.trim()) {
      Alert.alert("Error", "El nombre no puede estar vacío.");
      return;
    }
    setSaving(true);
    try {
      await updateProfile({
        displayName: newName.trim(),
        // photoURL necesita una URL pública; si es local URI guardamos como string
        // En producción se subiría a Firebase Storage primero
        photoURL: localPhoto ?? undefined,
      });
      setEditing(false);
      Alert.alert("✅ Guardado", "Tu perfil ha sido actualizado.");
    } catch {
      Alert.alert("Error", "No se pudo actualizar el perfil.");
    } finally {
      setSaving(false);
    }
  };

  const cancelEdit = () => {
    setNewName(profile?.displayName ?? "");
    setLocalPhoto(profile?.photoURL ?? null);
    setEditing(false);
  };

  // ── Estilos dinámicos ─────────────────────────────────────────────────────
  const s = makeStyles(colors);
  const photoUri = localPhoto ?? profile?.photoURL ?? null;
  const initials = profile?.isAnonymous
    ? "👤"
    : (profile?.displayName?.[0] ?? profile?.email?.[0] ?? "?").toUpperCase();

  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === "ios" ? "padding" : undefined}
      style={{ flex: 1, backgroundColor: colors.bg }}
    >
      <ScrollView
        style={{ flex: 1 }}
        contentContainerStyle={{ paddingBottom: insets.bottom + 20 }}
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps="handled"
      >
        {/* ── Header con avatar ──────────────────────────────────────────── */}
        <View style={[s.header, { paddingTop: insets.top + 16 }]}>
          <View style={s.headerAccent} />

          {/* Avatar con botón de edición */}
          <View style={s.avatarSection}>
            <Pressable onPress={editing ? showPhotoPicker : undefined} style={s.avatarWrap}>
              {photoUri ? (
                <Image source={{ uri: photoUri }} style={s.avatarImg} />
              ) : (
                <View style={s.avatar}>
                  <Text style={s.avatarText}>{initials}</Text>
                </View>
              )}
              {editing && (
                <View style={[s.avatarEdit, { backgroundColor: colors.primary }]}>
                  <Text style={{ color: "#fff", fontSize: 14 }}>📷</Text>
                </View>
              )}
            </Pressable>

            {/* Nombre / input de edición */}
            {editing ? (
              <View style={{ flex: 1 }}>
                <TextInput
                  style={[s.nameInput, { color: colors.text, borderColor: colors.primary, backgroundColor: colors.card }]}
                  value={newName}
                  onChangeText={setNewName}
                  placeholder="Tu nombre"
                  placeholderTextColor={colors.muted}
                  maxLength={40}
                  autoFocus
                />
                <Text style={[s.emailLabel, { color: colors.subtext }]}>
                  {profile?.isAnonymous ? "Cuenta temporal" : profile?.email}
                </Text>
              </View>
            ) : (
              <View style={{ flex: 1 }}>
                <Text style={s.name}>
                  {profile?.isAnonymous ? "Invitado" : (profile?.displayName ?? "Usuario")}
                </Text>
                <Text style={s.email}>
                  {profile?.isAnonymous ? "Cuenta temporal" : profile?.email}
                </Text>
                {profile?.isAnonymous && (
                  <Text style={[s.guestNotice, { color: colors.warning }]}>
                    ⚠️ Los datos se pierden al cerrar sesión
                  </Text>
                )}
              </View>
            )}
          </View>

          {/* Botones Editar / Guardar */}
          {!profile?.isAnonymous && (
            <View style={s.editRow}>
              {editing ? (
                <>
                  <Pressable
                    onPress={cancelEdit}
                    style={[s.editBtn, { backgroundColor: `${colors.muted}20`, borderColor: `${colors.muted}40` }]}
                  >
                    <Text style={[s.editBtnText, { color: colors.muted }]}>Cancelar</Text>
                  </Pressable>
                  <Pressable
                    onPress={handleSave}
                    disabled={saving}
                    style={[s.editBtn, { backgroundColor: `${colors.primary}20`, borderColor: `${colors.primary}50` }, saving && { opacity: 0.6 }]}
                  >
                    {saving
                      ? <ActivityIndicator size="small" color={colors.primary} />
                      : <Text style={[s.editBtnText, { color: colors.primary }]}>💾 Guardar</Text>}
                  </Pressable>
                </>
              ) : (
                <Pressable
                  onPress={() => { setNewName(profile?.displayName ?? ""); setLocalPhoto(profile?.photoURL ?? null); setEditing(true); }}
                  style={[s.editBtn, { backgroundColor: `${colors.primary}15`, borderColor: `${colors.primary}40` }]}
                >
                  <Text style={[s.editBtnText, { color: colors.primary }]}>✏️ Editar perfil</Text>
                </Pressable>
              )}
            </View>
          )}
        </View>

        {/* ── Estadísticas ─────────────────────────────────────────────────── */}
        <View style={s.section}>
          <Text style={s.sectionLabel}>Mis estadísticas</Text>
          <View style={s.statsGrid}>
            {[
              { label: "Hábitos",     value: totalHabits,      emoji: "📋" },
              { label: "Completados", value: totalCompletions, emoji: "✅" },
              { label: "Días activo", value: activeDays,       emoji: "📅" },
              { label: "Mejor racha", value: bestStreak,       emoji: "🏆" },
            ].map((stat) => (
              <View key={stat.label} style={s.statCard}>
                <Text style={{ fontSize: 24, marginBottom: 4 }}>{stat.emoji}</Text>
                <Text style={s.statValue}>{stat.value}</Text>
                <Text style={s.statLabel}>{stat.label}</Text>
              </View>
            ))}
          </View>
        </View>

        {/* ── Apariencia ──────────────────────────────────────────────────── */}
        <View style={s.section}>
          <Text style={s.sectionLabel}>Apariencia</Text>
          <View style={s.menuCard}>
            <View style={s.menuItem}>
              <Text style={s.menuIcon}>{isDark ? "🌙" : "☀️"}</Text>
              <Text style={s.menuLabel}>{isDark ? "Modo oscuro" : "Modo claro"}</Text>
              <Switch
                value={isDark}
                onValueChange={toggleTheme}
                trackColor={{ false: colors.border, true: `${colors.primary}80` }}
                thumbColor={isDark ? colors.primary : colors.muted}
                ios_backgroundColor={colors.border}
              />
            </View>
          </View>
        </View>

        {/* ── Cerrar sesión ────────────────────────────────────────────────── */}
        <View style={{ paddingHorizontal: 16, marginTop: 8 }}>
          <Pressable
            onPress={handleSignOut}
            style={({ pressed }) => [s.signOutBtn, pressed && { opacity: 0.8 }]}
          >
            <Text style={s.signOutText}>🚪 Cerrar sesión</Text>
          </Pressable>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

// ── Estilos dinámicos ─────────────────────────────────────────────────────────
function makeStyles(colors: ReturnType<typeof import("../../src/context/ThemeContext").useTheme>["colors"]) {
  return StyleSheet.create({
    header: {
      backgroundColor: colors.card,
      paddingHorizontal: 20,
      paddingBottom: 20,
      borderBottomWidth: 1,
      borderBottomColor: colors.cardBorder,
      marginBottom: 16,
    },
    headerAccent: { position: "absolute", top: 0, left: 0, right: 0, height: 3, backgroundColor: colors.primary },

    avatarSection:  { flexDirection: "row", alignItems: "center", gap: 16, marginBottom: 14 },
    avatarWrap:     { position: "relative" },
    avatar:         {
      width: 72, height: 72, borderRadius: 36,
      backgroundColor: `${colors.primary}25`,
      alignItems: "center", justifyContent: "center",
      borderWidth: 2, borderColor: colors.primary,
    },
    avatarImg:      { width: 72, height: 72, borderRadius: 36, borderWidth: 2, borderColor: colors.primary },
    avatarText:     { color: colors.text, fontSize: 28, fontWeight: "800" },
    avatarEdit:     {
      position: "absolute", bottom: 0, right: 0,
      width: 24, height: 24, borderRadius: 12,
      alignItems: "center", justifyContent: "center",
    },

    nameInput:   {
      fontSize: 17, fontWeight: "700",
      borderWidth: 1, borderRadius: radii.md,
      paddingHorizontal: 10, paddingVertical: 6,
      marginBottom: 4,
    },
    name:        { color: colors.text, fontSize: 20, fontWeight: "700" },
    emailLabel:  { fontSize: 12 },
    email:       { color: colors.subtext, fontSize: 13, marginTop: 2 },
    guestNotice: { fontSize: 11, marginTop: 4 },

    editRow:     { flexDirection: "row", gap: 8 },
    editBtn:     { flex: 1, borderRadius: radii.md, borderWidth: 1, paddingVertical: 9, alignItems: "center" },
    editBtnText: { fontSize: 13, fontWeight: "600" },

    section:      { paddingHorizontal: 16, marginBottom: 20 },
    sectionLabel: {
      color: colors.subtext, fontSize: 11,
      letterSpacing: 1, textTransform: "uppercase",
      fontWeight: "700", marginBottom: 10,
    },

    statsGrid: { flexDirection: "row", flexWrap: "wrap", gap: 8 },
    statCard:  {
      flex: 1, minWidth: "46%",
      backgroundColor: colors.card,
      borderRadius: radii.lg,
      borderWidth: 1, borderColor: colors.cardBorder,
      padding: 14, alignItems: "center",
    },
    statValue: { color: colors.text, fontSize: 22, fontWeight: "800" },
    statLabel: { color: colors.subtext, fontSize: 11 },

    menuCard:    {
      backgroundColor: colors.card,
      borderRadius: radii.lg,
      borderWidth: 1, borderColor: colors.cardBorder,
      overflow: "hidden",
    },
    menuItem:    { flexDirection: "row", alignItems: "center", paddingHorizontal: 16, paddingVertical: 14, gap: 12 },
    menuIcon:    { fontSize: 20 },
    menuLabel:   { color: colors.text, fontSize: 15, flex: 1 },

    signOutBtn: {
      backgroundColor: `${colors.accent}18`,
      borderRadius: radii.md,
      borderWidth: 1,
      borderColor: `${colors.accent}40`,
      paddingVertical: 14,
      alignItems: "center",
    },
    signOutText: { color: colors.accent, fontSize: 15, fontWeight: "600" },
  });
}
