import { useState, useRef, useCallback } from "react";
import * as ImagePicker from "expo-image-picker";

// ── Foto por hábito ────────────────────────────────────────────────────────────
export interface HabitPhoto {
  uri:       string;
  takenAt:   number; // timestamp ms
}

export interface CameraState {
  /** Mapa de habitId → fotos del día */
  photosByHabit: Record<string, HabitPhoto[]>;
  /** Toma foto para un hábito específico */
  takePhotoForHabit: (habitId: string) => Promise<string | null>;
  isAvailable: boolean;
  /** @deprecated — usa photosByHabit */
  photosToday:  number;
  lastPhotoUri: string | null;
}

/**
 * 📸 Camera hook — foto POR HÁBITO
 *
 * Cada hábito de tipo "camera" tiene su propio contador de fotos.
 * Múltiples hábitos con cámara NO comparten el mismo contador.
 */
export function useCamera(): CameraState {
  const [photosByHabit, setPhotosByHabit] = useState<Record<string, HabitPhoto[]>>({});
  const [isAvailable, setAvailable]       = useState(true);
  const [lastPhotoUri, setLastPhotoUri]   = useState<string | null>(null);
  const countRef = useRef(0);

  const takePhotoForHabit = useCallback(async (habitId: string): Promise<string | null> => {
    try {
      const { status } = await ImagePicker.requestCameraPermissionsAsync();
      if (status !== "granted") {
        setAvailable(false);
        console.warn("[Camera] ❌ Permiso de cámara denegado");
        return null;
      }

      const result = await ImagePicker.launchCameraAsync({
        mediaTypes: ["images"],
        quality:    0.7,
        allowsEditing: false,
      });

      if (!result.canceled && result.assets.length > 0) {
        const uri = result.assets[0].uri;
        const photo: HabitPhoto = { uri, takenAt: Date.now() };

        setPhotosByHabit((prev) => ({
          ...prev,
          [habitId]: [...(prev[habitId] ?? []), photo],
        }));
        setLastPhotoUri(uri);
        countRef.current += 1;
        console.log(`[Camera] 📸 Foto para hábito ${habitId}:`, uri);
        return uri;
      }
      return null;
    } catch (e) {
      console.error("[Camera] Error al tomar foto:", e);
      return null;
    }
  }, []);

  // Retrocompatibilidad — total de fotos de todos los hábitos
  const photosToday = Object.values(photosByHabit).reduce(
    (sum, arr) => sum + arr.length,
    0
  );

  return { photosByHabit, takePhotoForHabit, isAvailable, photosToday, lastPhotoUri };
}
