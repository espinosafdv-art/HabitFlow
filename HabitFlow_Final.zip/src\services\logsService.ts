import {
  doc, getDoc, setDoc, serverTimestamp,
} from "firebase/firestore";
import { db } from "./firebase";
import { toDateString } from "../utils/dateUtils";
import type { DailyLog } from "../types";

// MVT — MODEL: acceso a datos de logs diarios por hábito
function logDoc(userId: string, date: string, habitId: string) {
  return doc(db, "users", userId, "logs", date, "habits", habitId);
}

// ─── Leer log de hoy para un hábito ──────────────────────────────────────────
export async function getDailyLog(userId: string, habitId: string): Promise<DailyLog | null> {
  try {
    const snap = await getDoc(logDoc(userId, toDateString(), habitId));
    return snap.exists() ? (snap.data() as DailyLog) : null;
  } catch (e) {
    console.error("[logsService] getDailyLog:", e);
    return null;
  }
}

// ─── Upsert log (incluye photoUri opcional) ───────────────────────────────────
export async function upsertDailyLog(
  userId:    string,
  habitId:   string,
  current:   number,
  target:    number,
  photoUri?: string | null   // ← URI de foto para hábitos de cámara
): Promise<void> {
  const date      = toDateString();
  const completed = current >= target;
  const ref       = logDoc(userId, date, habitId);

  try {
    const snap     = await getDoc(ref);
    const existing = snap.exists() ? (snap.data() as DailyLog) : null;

    const payload: Record<string, any> = {
      habitId,
      date,
      current,
      completed,
      updatedAt:   serverTimestamp(),
      completedAt:
        completed && !existing?.completed
          ? serverTimestamp()
          : (existing?.completedAt ?? null),
    };

    // Solo persiste la URI si se proporciona (no sobreescribe con null)
    if (photoUri) payload.photoUri = photoUri;

    await setDoc(ref, payload, { merge: true });
    console.log(`[logsService] ✅ Log guardado — hábito ${habitId}, current=${current}, foto=${!!photoUri}`);
  } catch (e) {
    console.error("[logsService] upsertDailyLog:", e);
    throw e;
  }
}

// ─── Leer todos los logs de hoy para un usuario ───────────────────────────────
export async function fetchTodayLogs(
  userId:   string,
  habitIds: string[]
): Promise<Record<string, DailyLog>> {
  const date    = toDateString();
  const results: Record<string, DailyLog> = {};

  await Promise.all(
    habitIds.map(async (id) => {
      const snap = await getDoc(logDoc(userId, date, id)).catch(() => null);
      if (snap?.exists()) results[id] = snap.data() as DailyLog;
    })
  );

  return results;
}
