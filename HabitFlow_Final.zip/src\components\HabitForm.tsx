/**
 * MVT — TEMPLATE (componente reutilizable)
 * src/components/HabitForm.tsx
 *
 * Formulario para crear/editar hábitos.
 * Sin foto de portada — la foto diaria la maneja el sensor de cámara.
 * Usa useTheme() para soporte dark/light.
 */
import React, { useState } from "react";
import {
  View, Text, TextInput, ScrollView, Pressable,
  StyleSheet, Alert, KeyboardAvoidingView, Platform,
} from "react-native";
import { useTheme }   from "../context/ThemeContext";
import { radii }      from "../utils/theme";
import type { HabitFormData, SensorType } from "../types";

// ─── Presets ──────────────────────────────────────────────────────────────────
export const PRESET_EMOJIS = [
  "📸","🏃","🧠","📍","💪","🏋","🚴","🏊","🧘","📚",
  "🎯","💧","🌿","😴","⭐","🔥","✨","🎨","🎵","🍎",
  "🏆","💊","🛏","☕","🌅","🦷","🧴","🏔","🌊","💼",
];

export const PRESET_COLORS = [
  "#6C63FF","#FF6584","#F59E0B","#22C55E",
  "#3B82F6","#14B8A6","#EC4899","#F97316",
];

export const SENSOR_OPTIONS: {
  value: SensorType; label: string; icon: string; defaultUnit: string;
}[] = [
  { value: "manual",        label: "Manual",       icon: "👆", defaultUnit: "veces" },
  { value: "camera",        label: "Cámara",       icon: "📸", defaultUnit: "foto" },
  { value: "accelerometer", label: "Acelerómetro", icon: "🏃", defaultUnit: "pts" },
  { value: "gyroscope",     label: "Giroscopio",   icon: "🧠", defaultUnit: "min" },
  { value: "location",      label: "GPS",          icon: "📍", defaultUnit: "m" },
];

// ─── Props ────────────────────────────────────────────────────────────────────
interface HabitFormProps {
  initialData?:  Partial<HabitFormData>;
  onSubmit:      (data: HabitFormData) => Promise<void>;
  submitLabel:   string;
  onCancel:      () => void;
}

const DEFAULT_FORM: HabitFormData = {
  name:        "",
  emoji:       "⭐",
  color:       "#6C63FF",
  target:      1,
  unit:        "veces",
  description: "",
  sensorType:  "manual",
};

export function HabitForm({ initialData, onSubmit, submitLabel, onCancel }: HabitFormProps) {
  const { colors }          = useTheme();
  const [form, setForm]     = useState<HabitFormData>({ ...DEFAULT_FORM, ...initialData });
  const [submitting, setSubmitting] = useState(false);

  const update = (field: keyof HabitFormData, value: any) =>
    setForm((f) => ({ ...f, [field]: value }));

  const handleSensorChange = (sensorType: SensorType) => {
    const opt = SENSOR_OPTIONS.find((o) => o.value === sensorType)!;
    setForm((f) => ({ ...f, sensorType, unit: opt.defaultUnit }));
  };

  const handleSubmit = async () => {
    if (!form.name.trim()) { Alert.alert("Error", "El nombre del hábito es requerido."); return; }
    if (form.target <= 0)  { Alert.alert("Error", "La meta debe ser mayor a 0."); return; }
    setSubmitting(true);
    try { await onSubmit(form); }
    catch { Alert.alert("Error", "No se pudo guardar el hábito."); }
    finally { setSubmitting(false); }
  };

  // ── Estilos dinámicos ─────────────────────────────────────────────────────
  const inp: any = {
    backgroundColor: colors.inputBg ?? colors.card,
    borderRadius:    radii.md,
    borderWidth:     1,
    borderColor:     colors.border ?? colors.cardBorder,
    color:           colors.text,
    fontSize:        15,
    paddingHorizontal: 14,
    paddingVertical:   12,
  };

  return (
    <KeyboardAvoidingView behavior={Platform.OS === "ios" ? "padding" : undefined} style={{ flex: 1 }}>
      <ScrollView style={{ flex: 1, paddingHorizontal: 16, paddingTop: 8 }} showsVerticalScrollIndicator={false}>

        {/* Preview */}
        <View style={[st.preview, { backgroundColor: `${form.color}20`, borderColor: `${form.color}50` }]}>
          <Text style={{ fontSize: 30 }}>{form.emoji}</Text>
          <Text style={[st.previewName, { color: form.color }]}>{form.name || "Mi hábito"}</Text>
        </View>

        {/* Nombre */}
        <Text style={[st.label, { color: colors.subtext ?? colors.muted }]}>Nombre</Text>
        <TextInput
          style={inp}
          value={form.name}
          onChangeText={(v) => update("name", v)}
          placeholder="Ej. Meditar 10 minutos"
          placeholderTextColor={colors.muted}
          maxLength={40}
        />

        {/* Descripción */}
        <Text style={[st.label, { color: colors.subtext ?? colors.muted }]}>Descripción (opcional)</Text>
        <TextInput
          style={[inp, { height: 80, textAlignVertical: "top" }]}
          value={form.description}
          onChangeText={(v) => update("description", v)}
          placeholder="¿Qué quieres lograr con este hábito?"
          placeholderTextColor={colors.muted}
          multiline
          numberOfLines={3}
          maxLength={120}
        />

        {/* Emoji picker */}
        <Text style={[st.label, { color: colors.subtext ?? colors.muted }]}>Ícono</Text>
        <View style={st.emojiGrid}>
          {PRESET_EMOJIS.map((e) => (
            <Pressable
              key={e}
              onPress={() => update("emoji", e)}
              style={[st.emojiBtn,
                { backgroundColor: colors.card, borderColor: "transparent" },
                form.emoji === e && { backgroundColor: `${form.color}30`, borderColor: form.color }]}
            >
              <Text style={{ fontSize: 22 }}>{e}</Text>
            </Pressable>
          ))}
        </View>

        {/* Color picker */}
        <Text style={[st.label, { color: colors.subtext ?? colors.muted }]}>Color</Text>
        <View style={st.colorRow}>
          {PRESET_COLORS.map((c) => (
            <Pressable
              key={c}
              onPress={() => update("color", c)}
              style={[st.colorDot, { backgroundColor: c },
                form.color === c && { borderWidth: 3, borderColor: colors.text, transform: [{ scale: 1.15 }] }]}
            />
          ))}
        </View>

        {/* Tipo de sensor */}
        <Text style={[st.label, { color: colors.subtext ?? colors.muted }]}>Tipo de seguimiento</Text>
        <View style={st.sensorGrid}>
          {SENSOR_OPTIONS.map((opt) => (
            <Pressable
              key={opt.value}
              onPress={() => handleSensorChange(opt.value)}
              style={[st.sensorBtn,
                { backgroundColor: colors.card, borderColor: colors.cardBorder },
                form.sensorType === opt.value && { backgroundColor: `${form.color}20`, borderColor: form.color }]}
            >
              <Text style={{ fontSize: 20, marginBottom: 4 }}>{opt.icon}</Text>
              <Text style={[st.sensorLabel, { color: colors.muted },
                form.sensorType === opt.value && { color: form.color }]}>
                {opt.label}
              </Text>
            </Pressable>
          ))}
        </View>

        {/* Meta + Unidad */}
        <View style={{ flexDirection: "row" }}>
          <View style={{ flex: 1 }}>
            <Text style={[st.label, { color: colors.subtext ?? colors.muted }]}>Meta diaria</Text>
            <TextInput
              style={inp}
              value={String(form.target)}
              onChangeText={(v) => update("target", Number(v.replace(/[^0-9]/g, "")) || 1)}
              keyboardType="numeric"
            />
          </View>
          <View style={{ flex: 1, marginLeft: 12 }}>
            <Text style={[st.label, { color: colors.subtext ?? colors.muted }]}>Unidad</Text>
            <TextInput
              style={inp}
              value={form.unit}
              onChangeText={(v) => update("unit", v)}
              placeholder="pasos, min, fotos…"
              placeholderTextColor={colors.muted}
              maxLength={15}
            />
          </View>
        </View>

        {/* Acciones */}
        <View style={{ flexDirection: "row", gap: 12, marginTop: 24 }}>
          <Pressable
            onPress={onCancel}
            style={[st.cancelBtn, { borderColor: colors.cardBorder }]}
          >
            <Text style={[st.cancelText, { color: colors.muted }]}>Cancelar</Text>
          </Pressable>
          <Pressable
            onPress={handleSubmit}
            disabled={submitting}
            style={[st.submitBtn, { backgroundColor: form.color }, submitting && { opacity: 0.6 }]}
          >
            <Text style={st.submitText}>{submitting ? "Guardando…" : submitLabel}</Text>
          </Pressable>
        </View>

        <View style={{ height: 40 }} />
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const st = StyleSheet.create({
  preview:     { flexDirection: "row", alignItems: "center", gap: 10, borderRadius: radii.lg, borderWidth: 1, padding: 14, marginTop: 8 },
  previewName: { fontSize: 18, fontWeight: "700", flex: 1 },
  label:       { fontSize: 11, letterSpacing: 1, textTransform: "uppercase", marginBottom: 8, marginTop: 16 },
  emojiGrid:   { flexDirection: "row", flexWrap: "wrap", gap: 8 },
  emojiBtn:    { width: 44, height: 44, borderRadius: radii.md, alignItems: "center", justifyContent: "center", borderWidth: 1 },
  colorRow:    { flexDirection: "row", gap: 10, flexWrap: "wrap" },
  colorDot:    { width: 32, height: 32, borderRadius: 16 },
  sensorGrid:  { flexDirection: "row", flexWrap: "wrap", gap: 8 },
  sensorBtn:   { paddingHorizontal: 12, paddingVertical: 10, borderRadius: radii.md, borderWidth: 1, alignItems: "center", minWidth: "30%" },
  sensorLabel: { fontSize: 11, fontWeight: "500" },
  cancelBtn:   { flex: 1, paddingVertical: 14, borderRadius: radii.md, borderWidth: 1, alignItems: "center" },
  cancelText:  { fontSize: 15 },
  submitBtn:   { flex: 2, paddingVertical: 14, borderRadius: radii.md, alignItems: "center" },
  submitText:  { color: "#fff", fontSize: 15, fontWeight: "700" },
});
