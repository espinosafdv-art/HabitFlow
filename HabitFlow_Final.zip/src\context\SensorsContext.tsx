/**
 * MVT — ViewModel / Sensor Bridge
 * src/context/SensorsContext.tsx
 *
 * NOTA: En la arquitectura MVT v2, la integración de sensores fue migrada
 * directamente a HabitsContext.tsx para centralizar el estado.
 * Este archivo queda como stub de compatibilidad (no se usa activamente).
 *
 * Los sensores activos son: Accelerometer, Gyroscope, Camera, GPS Location
 * Sus hooks se encuentran en src/hooks/
 */
import React, { createContext, useContext } from "react";

// ─── Tipos básicos de estado de sensor ───────────────────────────────────────
export interface SensorStatus {
  accelerometer: boolean;
  gyroscope:     boolean;
  location:      boolean;
  camera:        boolean;
}

export interface SensorsContextValue {
  sensorStatus: SensorStatus;
}

// ─── Valores por defecto ──────────────────────────────────────────────────────
const DEFAULT_STATUS: SensorStatus = {
  accelerometer: true,
  gyroscope:     true,
  location:      true,
  camera:        true,
};

const SensorsContext = createContext<SensorsContextValue>({
  sensorStatus: DEFAULT_STATUS,
});

/**
 * SensorsProvider — stub de compatibilidad.
 * La lógica real de sensores vive en HabitsContext (src/context/HabitsContext.tsx).
 */
export function SensorsProvider({ children }: { children: React.ReactNode }) {
  return (
    <SensorsContext.Provider value={{ sensorStatus: DEFAULT_STATUS }}>
      {children}
    </SensorsContext.Provider>
  );
}

export function useSensors(): SensorsContextValue {
  return useContext(SensorsContext);
}
