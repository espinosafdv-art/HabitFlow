/**
 * MVT — ViewModel
 * src/context/ThemeContext.tsx
 *
 * Modo oscuro / claro con persistencia en AsyncStorage.
 * Provee tokens de color dinámicos a toda la app.
 */
import React, { createContext, useContext, useEffect, useState, useCallback } from "react";
import AsyncStorage from "@react-native-async-storage/async-storage";

// ─── Tipo de colores del tema ─────────────────────────────────────────────────
export type ThemeColors = {
  bg:        string;
  card:      string;
  cardBorder:string;
  primary:   string;
  success:   string;
  warning:   string;
  accent:    string;
  muted:     string;
  white:     string;
  text:      string;
  subtext:   string;
  border:    string;
  inputBg:   string;
  statusBar: "light" | "dark";
  isDark:    boolean;
};

// ─── Paleta oscura ────────────────────────────────────────────────────────────
const DARK: ThemeColors = {
  bg:          "#13131F",
  card:        "#1E1E2E",
  cardBorder:  "rgba(255,255,255,0.07)",
  primary:     "#6C63FF",
  success:     "#22C55E",
  warning:     "#F59E0B",
  accent:      "#FF6584",
  muted:       "#A0A0B2",
  white:       "#FFFFFF",
  text:        "#FFFFFF",
  subtext:     "#A0A0B2",
  border:      "#2A2A3E",
  inputBg:     "#252535",
  statusBar:   "light",
  isDark:      true,
};

// ─── Paleta clara ─────────────────────────────────────────────────────────────
const LIGHT: ThemeColors = {
  bg:          "#F0F0F8",
  card:        "#FFFFFF",
  cardBorder:  "rgba(0,0,0,0.08)",
  primary:     "#6C63FF",
  success:     "#16A34A",
  warning:     "#D97706",
  accent:      "#E5365A",
  muted:       "#6B7280",
  white:       "#FFFFFF",
  text:        "#111827",
  subtext:     "#6B7280",
  border:      "#E5E7EB",
  inputBg:     "#F9F9FF",
  statusBar:   "dark",
  isDark:      false,
};

const STORAGE_KEY = "@hf/theme";

// ─── Context ──────────────────────────────────────────────────────────────────
interface ThemeContextValue {
  colors:      ThemeColors;
  isDark:      boolean;
  toggleTheme: () => void;
}

const ThemeContext = createContext<ThemeContextValue>({
  colors:      DARK,
  isDark:      true,
  toggleTheme: () => {},
});

// ─── Provider ─────────────────────────────────────────────────────────────────
export function ThemeProvider({ children }: { children: React.ReactNode }) {
  const [isDark, setIsDark] = useState(true);

  // Cargar preferencia guardada al iniciar
  useEffect(() => {
    AsyncStorage.getItem(STORAGE_KEY).then((val) => {
      if (val !== null) setIsDark(val === "dark");
    });
  }, []);

  const toggleTheme = useCallback(() => {
    setIsDark((prev) => {
      const next = !prev;
      AsyncStorage.setItem(STORAGE_KEY, next ? "dark" : "light");
      return next;
    });
  }, []);

  return (
    <ThemeContext.Provider value={{ colors: isDark ? DARK : LIGHT, isDark, toggleTheme }}>
      {children}
    </ThemeContext.Provider>
  );
}

export function useTheme(): ThemeContextValue {
  return useContext(ThemeContext);
}
