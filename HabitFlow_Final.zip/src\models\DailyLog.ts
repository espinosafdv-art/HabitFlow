/**
 * MVT — CAPA MODEL
 * src/models/DailyLog.ts
 *
 * Entidad DailyLog: registra el progreso diario de un hábito.
 */
import type { Timestamp } from "firebase/firestore";

// ─── DailyLog Entity ─────────────────────────────────────────────────────────
export interface DailyLog {
  habitId:     string;
  date:        string;        // YYYY-MM-DD
  current:     number;        // progreso actual
  completed:   boolean;
  updatedAt:   Timestamp | null;
  completedAt: Timestamp | null;
}

// ─── StreakData Entity ────────────────────────────────────────────────────────
export interface StreakData {
  habitId:           string;
  currentStreak:     number;
  longestStreak:     number;
  totalCompletions:  number;
  lastCompletedDate: string | null; // YYYY-MM-DD
}

// ─── Sensor Readings (snapshot en memoria) ───────────────────────────────────
export interface SensorReadings {
  photosToday:    number;
  lastPhotoUri:   string | null;
  activityScore:  number;
  minutesFlipped: number;
  distanceMeters: number;
}

// ─── Factory — log vacío para un hábito en un día nuevo ─────────────────────
export function createEmptyLog(habitId: string): DailyLog {
  return {
    habitId,
    date:        new Date().toISOString().slice(0, 10),
    current:     0,
    completed:   false,
    updatedAt:   null,
    completedAt: null,
  };
}

// ─── Factory — streak vacío para un hábito nuevo ─────────────────────────────
export function createEmptyStreak(habitId: string): StreakData {
  return {
    habitId,
    currentStreak:     0,
    longestStreak:     0,
    totalCompletions:  0,
    lastCompletedDate: null,
  };
}
