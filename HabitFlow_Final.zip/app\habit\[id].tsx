import React from "react";
import { View, Text, Pressable, StyleSheet, ActivityIndicator, Alert, ScrollView } from "react-native";
import { useLocalSearchParams, useRouter } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { HabitForm }  from "../../src/components/HabitForm";
import { useHabits }  from "../../src/context/HabitsContext";
import { useTheme }   from "../../src/context/ThemeContext";
import { radii }      from "../../src/utils/theme";
import type { HabitFormData } from "../../src/types";

export default function EditHabitScreen() {
  const insets    = useSafeAreaInsets();
  const router    = useRouter();
  const { id }    = useLocalSearchParams<{ id: string }>();
  const { colors } = useTheme();
  const { habits, streaks, todayLogs, updateHabit, deleteHabit } = useHabits();
  const habit  = habits.find((h) => h.id === id);
  const streak = id ? streaks[id]  : undefined;
  const log    = id ? todayLogs[id] : undefined;

  if (!habit) return <View style={{ flex: 1, backgroundColor: colors.bg, justifyContent: "center", alignItems: "center" }}><ActivityIndicator color={colors.primary} /></View>;

  const initialData: HabitFormData = { name: habit.name, emoji: habit.emoji, color: habit.color, target: habit.target, unit: habit.unit, description: habit.description, sensorType: habit.sensorType };
  const handleSubmit = async (data: HabitFormData) => { await updateHabit(id, data); router.back(); };
  const handleDelete = () => {
    Alert.alert(`Eliminar "${habit.name}"`, "Esta acción no se puede deshacer.", [
      { text: "Cancelar", style: "cancel" },
      { text: "Eliminar", style: "destructive", onPress: async () => { await deleteHabit(id); router.back(); } },
    ]);
  };

  return (
    <View style={{ flex: 1, backgroundColor: colors.bg, paddingTop: insets.top }}>
      <View style={[styles.header, { backgroundColor: colors.card, borderBottomColor: colors.cardBorder }]}>
        <View style={[styles.handle, { backgroundColor: colors.border }]} />
        <Text style={[styles.title, { color: colors.text }]}>\u270F\uFE0F Editar hábito</Text>
        <Pressable onPress={() => router.back()} style={styles.closeBtn}><Text style={[styles.closeText, { color: colors.subtext }]}>\u2715</Text></Pressable>
      </View>
      <ScrollView showsVerticalScrollIndicator={false}>
        <View style={[styles.statsBar, { backgroundColor: colors.card, borderBottomColor: colors.cardBorder }]}>
          <View style={styles.statItem}>
            <Text style={[styles.statValue, { color: colors.text }]}>{log?.completed ? "\u2705" : log ? `${Math.round(log.current)}/${habit.target}` : "—"}</Text>
            <Text style={[styles.statLabel, { color: colors.subtext }]}>Hoy</Text>
          </View>
          <View style={[styles.statDivider, { backgroundColor: colors.cardBorder }]} />
          <View style={styles.statItem}>
            <Text style={[styles.statValue, { color: colors.text }]}>{streak?.currentStreak ?? 0} \uD83D\uDD25</Text>
            <Text style={[styles.statLabel, { color: colors.subtext }]}>Racha actual</Text>
          </View>
          <View style={[styles.statDivider, { backgroundColor: colors.cardBorder }]} />
          <View style={styles.statItem}>
            <Text style={[styles.statValue, { color: colors.text }]}>{streak?.longestStreak ?? 0} \uD83C\uDFC6</Text>
            <Text style={[styles.statLabel, { color: colors.subtext }]}>Mejor racha</Text>
          </View>
        </View>
        <HabitForm initialData={initialData} submitLabel="Guardar cambios" onSubmit={handleSubmit} onCancel={() => router.back()} />
        <View style={{ paddingHorizontal: 16, marginBottom: 40 }}>
          <Pressable onPress={handleDelete} style={[styles.deleteBtn, { backgroundColor: "rgba(255,101,132,0.1)", borderColor: "rgba(255,101,132,0.35)" }]}>
            <Text style={styles.deleteText}>\uD83D\uDDD1\uFE0F Eliminar este hábito</Text>
          </Pressable>
        </View>
      </ScrollView>
    </View>
  );
}
const styles = StyleSheet.create({
  header:      { flexDirection: "row", alignItems: "center", paddingHorizontal: 16, paddingVertical: 14, borderBottomWidth: 1 },
  handle:      { position: "absolute", top: 8, left: "50%", width: 40, height: 4, borderRadius: 2, marginLeft: -20 },
  title:       { flex: 1, fontSize: 18, fontWeight: "700", textAlign: "center" },
  closeBtn:    { padding: 8 },
  closeText:   { fontSize: 20 },
  statsBar:    { flexDirection: "row", justifyContent: "space-around", paddingVertical: 16, borderBottomWidth: 1 },
  statItem:    { alignItems: "center" },
  statValue:   { fontSize: 18, fontWeight: "700" },
  statLabel:   { fontSize: 11, marginTop: 2 },
  statDivider: { width: 1 },
  deleteBtn:   { borderRadius: radii.md, borderWidth: 1, paddingVertical: 14, alignItems: "center" },
  deleteText:  { color: "#FF6584", fontSize: 15, fontWeight: "600" },
});
