import React from "react";
import { View, Text, Pressable, StyleSheet } from "react-native";
import { useRouter }           from "expo-router";
import { useSafeAreaInsets }   from "react-native-safe-area-context";
import { HabitForm }           from "../../src/components/HabitForm";
import { useHabits }           from "../../src/context/HabitsContext";
import { useTheme }            from "../../src/context/ThemeContext";
import type { HabitFormData }  from "../../src/types";

export default function NewHabitScreen() {
  const insets     = useSafeAreaInsets();
  const router     = useRouter();
  const { colors } = useTheme();
  const { addHabit } = useHabits();
  const handleSubmit = async (data: HabitFormData) => { await addHabit(data); router.back(); };
  return (
    <View style={{ flex: 1, backgroundColor: colors.bg, paddingTop: insets.top }}>
      <View style={[styles.header, { backgroundColor: colors.card, borderBottomColor: colors.cardBorder }]}>
        <View style={[styles.handle, { backgroundColor: colors.border }]} />
        <Text style={[styles.title, { color: colors.text }]}>\u2728 Nuevo hábito</Text>
        <Pressable onPress={() => router.back()} style={styles.closeBtn}><Text style={[styles.closeText, { color: colors.subtext }]}>\u2715</Text></Pressable>
      </View>
      <HabitForm submitLabel="Crear hábito" onSubmit={handleSubmit} onCancel={() => router.back()} />
    </View>
  );
}
const styles = StyleSheet.create({
  header:    { flexDirection: "row", alignItems: "center", paddingHorizontal: 16, paddingVertical: 14, borderBottomWidth: 1 },
  handle:    { position: "absolute", top: 8, left: "50%", width: 40, height: 4, borderRadius: 2, marginLeft: -20 },
  title:     { flex: 1, fontSize: 18, fontWeight: "700", textAlign: "center" },
  closeBtn:  { padding: 8 },
  closeText: { fontSize: 20 },
});
