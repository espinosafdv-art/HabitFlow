/**
 * MVT — CAPA MODEL (barrel export)
 * src/models/index.ts
 *
 * Punto de entrada único para todos los modelos del dominio.
 * Los Contexts (ViewModel) y las Vistas importan desde aquí.
 */
export type { Habit, HabitFormData, SensorType }  from "./Habit";
export { createOptimisticHabit, validateHabitForm } from "./Habit";

export type { DailyLog, StreakData, SensorReadings } from "./DailyLog";
export { createEmptyLog, createEmptyStreak }          from "./DailyLog";
