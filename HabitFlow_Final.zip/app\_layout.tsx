/**
 * MVT — VISTA / ViewModel
 * app/_layout.tsx — Root Layout (SOLUCIÓN DEFINITIVA)
 *
 * PROBLEMA RAÍZ: Expo Router mantiene su propio estado de navegación
 * independiente del árbol React. Cuando el árbol cambia (user null→user),
 * Expo Router puede intentar renderizar pantallas autenticadas ANTES de
 * que HabitsProvider esté disponible.
 *
 * SOLUCIÓN: Renderizado condicional SÍNCRONO de dos Stacks distintos.
 * - Stack AUTH:  Solo login/register. HabitsProvider NO existe aquí.
 * - Stack APP:   Tabs + Modales. HabitsProvider envuelve TODO este Stack.
 *
 * Como son dos Stacks distintos, Expo Router NO puede renderizar pantallas
 * del Stack APP cuando el usuario no está autenticado (y viceversa).
 * No hay race condition posible.
 */
import React from "react";
import { Stack } from "expo-router";
import { StatusBar } from "expo-status-bar";
import { SafeAreaProvider } from "react-native-safe-area-context";
import { View, ActivityIndicator, StyleSheet } from "react-native";
import { AuthProvider, useAuth }       from "../src/context/AuthContext";
import { HabitsProvider }              from "../src/context/HabitsContext";
import { NotificationsProvider }       from "../src/context/NotificationsContext";
import { ThemeProvider, useTheme }     from "../src/context/ThemeContext";
import { colors }                      from "../src/utils/theme";

// ─── Stack de autenticación (sin providers de datos) ─────────────────────────
function AuthStack() {
  return (
    <Stack screenOptions={{ headerShown: false, animation: "fade" }}>
      <Stack.Screen name="login"    />
      <Stack.Screen name="register" />
    </Stack>
  );
}

// ─── Stack autenticado ────────────────────────────────────────────────────────
function AppStack() {
  const { colors: tc } = useTheme();
  return (
    <Stack
      screenOptions={{
        headerShown:  false,
        contentStyle: { backgroundColor: tc.bg },
        animation:    "slide_from_right",
      }}
    >
      <Stack.Screen name="(tabs)"     options={{ animation: "fade" }} />
      <Stack.Screen
        name="habit/new"
        options={{ presentation: "modal", animation: "slide_from_bottom" }}
      />
      <Stack.Screen
        name="habit/[id]"
        options={{ presentation: "modal", animation: "slide_from_bottom" }}
      />
    </Stack>
  );
}

// ─── Shell — elige qué Stack montar según estado de auth ───────────────────────
function AppShell() {
  const { user, isLoading } = useAuth();
  const { colors: tc, isDark } = useTheme();

  if (isLoading) {
    return (
      <View style={[styles.splash, { backgroundColor: tc.bg }]}>
        <ActivityIndicator size="large" color={tc.primary} />
      </View>
    );
  }

  if (!user) return <AuthStack />;

  // HabitsProvider + NotificationsProvider envuelven AppStack
  // para garantizar que NUNCA monten modales sin el provider
  return (
    <NotificationsProvider>
      <HabitsProvider userId={user.uid}>
        <AppStack />
      </HabitsProvider>
    </NotificationsProvider>
  );
}

// ─── Root Layout ──────────────────────────────────────────────────────────────
export default function RootLayout() {
  return (
    <ThemeProvider>
      <SafeAreaProvider>
        <StatusBar style="auto" />
        <AuthProvider>
          <AppShell />
        </AuthProvider>
      </SafeAreaProvider>
    </ThemeProvider>
  );
}

const styles = StyleSheet.create({
  splash: {
    flex:            1,
    backgroundColor: colors.bg,
    justifyContent:  "center",
    alignItems:      "center",
  },
});
