/**
 * MVT — CAPA MODEL
 * src/models/Habit.ts
 *
 * Define la entidad Habit con su tipo, validaciones y factory function.
 * Separación clara de la lógica de dominio vs. la capa de persistencia.
 */
import type { Timestamp } from "firebase/firestore";

// ─── Sensor Types ─────────────────────────────────────────────────────────────
export type SensorType = "manual" | "accelerometer" | "gyroscope" | "location" | "camera";

// ─── Habit Entity ─────────────────────────────────────────────────────────────
export interface Habit {
  id:          string;
  userId:      string;
  name:        string;
  emoji:       string;
  description: string;
  sensorType:  SensorType;
  target:      number;
  unit:        string;
  isActive:    boolean;
  createdAt:   Timestamp | null;
}

// ─── Form Data (sin campos generados por el servidor) ─────────────────────────
export interface HabitFormData {
  name:        string;
  emoji:       string;
  description: string;
  sensorType:  SensorType;
  target:      number;
  unit:        string;
}

// ─── Factory — crea un Habit optimista antes de la respuesta de Firestore ─────
export function createOptimisticHabit(
  id: string,
  userId: string,
  data: HabitFormData
): Habit {
  return {
    ...data,
    id,
    userId,
    isActive:  true,
    createdAt: null,
  };
}

// ─── Validador de formulario ──────────────────────────────────────────────────
export function validateHabitForm(data: Partial<HabitFormData>): string | null {
  if (!data.name?.trim())        return "El nombre es requerido";
  if (!data.emoji?.trim())       return "Selecciona un emoji";
  if (!data.sensorType)          return "Selecciona el tipo de sensor";
  if (!data.target || data.target <= 0) return "La meta debe ser mayor a 0";
  return null; // válido
}
