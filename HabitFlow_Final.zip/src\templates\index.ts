/**
 * MVT — CAPA TEMPLATE (barrel export)
 * src/templates/index.ts
 *
 * Punto de entrada único para todos los templates reutilizables.
 */
export { ScreenLayout }  from "./layouts/ScreenLayout";
export { SectionHeader } from "./ui/SectionHeader";
export { EmptyState }    from "./ui/EmptyState";
