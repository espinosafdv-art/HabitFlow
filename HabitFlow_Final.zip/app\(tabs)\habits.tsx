import React from "react";
import {
  View, Text, ScrollView, Pressable, Alert, StyleSheet, ActivityIndicator,
} from "react-native";
import { useRouter }          from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useHabits }         from "../../src/context/HabitsContext";
import { useTheme }          from "../../src/context/ThemeContext";
import { StreakBadge }       from "../../src/components/StreakBadge";
import { radii, shadows }    from "../../src/utils/theme";
import type { Habit }        from "../../src/types";

export default function HabitsScreen() {
  const insets    = useSafeAreaInsets();
  const router    = useRouter();
  const { colors } = useTheme();
  const { habits, todayLogs, streaks, isLoading, deleteHabit } = useHabits();

  const handleDelete = (habit: Habit) => {
    Alert.alert(
      `Eliminar "${habit.name}"`,
      "¿Estás seguro? Esta acción no se puede deshacer.",
      [
        { text: "Cancelar", style: "cancel" },
        {
          text: "Eliminar",
          style: "destructive",
          onPress: () => deleteHabit(habit.id),
        },
      ]
    );
  };

  if (isLoading) {
    return (
      <View style={{ flex: 1, backgroundColor: colors.bg, justifyContent: "center", alignItems: "center" }}>
        <ActivityIndicator size="large" color={colors.primary} />
      </View>
    );
  }

  return (
    <View style={{ flex: 1, backgroundColor: colors.bg, paddingBottom: insets.bottom }}>
      <View style={[styles.header, { paddingTop: insets.top + 16, backgroundColor: colors.card, borderBottomColor: colors.cardBorder }]}>
        <View style={[styles.headerAccent, { backgroundColor: colors.primary }]} />
        <View style={styles.headerRow}>
          <Text style={[styles.title, { color: colors.text }]}>📋 Mis Hábitos</Text>
          <Pressable onPress={() => router.push("/habit/new")} style={[styles.addBtn, { backgroundColor: colors.primary }]}>
            <Text style={styles.addBtnText}>+ Agregar</Text>
          </Pressable>
        </View>
        <Text style={[styles.subtitle, { color: colors.subtext }]}>
          {habits.length === 0 ? "Sin hábitos" : `${habits.length} hábito${habits.length > 1 ? "s" : ""} activo${habits.length > 1 ? "s" : ""}`}
        </Text>
      </View>

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ padding: 16, gap: 12 }}>
        {habits.length === 0 && (
          <View style={styles.empty}>
            <Text style={styles.emptyEmoji}>📋</Text>
            <Text style={[styles.emptyTitle, { color: colors.text }]}>Sin hábitos todavía</Text>
            <Text style={[styles.emptySub, { color: colors.subtext }]}>Crea hábitos para comenzar tu racha</Text>
            <Pressable onPress={() => router.push("/habit/new")} style={[styles.emptyBtn, { backgroundColor: colors.primary }]}>
              <Text style={styles.emptyBtnText}>Crear primer hábito</Text>
            </Pressable>
          </View>
        )}

        {habits.map((habit) => {
          const log    = todayLogs[habit.id];
          const streak = streaks[habit.id];
          return (
            <View key={habit.id} style={[styles.card, { backgroundColor: colors.card, borderColor: colors.cardBorder, borderLeftColor: habit.color, borderLeftWidth: 4 }]}>
              <View style={styles.cardTop}>
                <View style={[styles.emojiWrap, { backgroundColor: `${habit.color}20` }]}>
                  <Text style={{ fontSize: 24 }}>{habit.emoji}</Text>
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={[styles.habitName, { color: colors.text }]}>{habit.name}</Text>
                  <Text style={[styles.habitSub, { color: colors.subtext }]}>
                    Meta: {habit.target} {habit.unit} · {SENSOR_LABEL[habit.sensorType] ?? habit.sensorType}
                  </Text>
                </View>
                {streak && <StreakBadge streak={streak} compact />}
              </View>

              <View style={styles.todayRow}>
                <View style={[styles.todayBadge, log?.completed ? styles.todayDone : styles.todayPending]}>
                  <Text style={[styles.todayBadgeText, { color: colors.text }]}>
                    {log?.completed ? "✅ Completado hoy" : log ? `⏳ ${Math.round(log.current)}/${habit.target} ${habit.unit}` : "⦿ Sin progreso"}
                  </Text>
                </View>
              </View>

              {habit.description ? (
                <Text style={[styles.description, { color: colors.subtext }]} numberOfLines={2}>{habit.description}</Text>
              ) : null}

              <View style={styles.actions}>
                <Pressable onPress={() => router.push(`/habit/${habit.id}`)} style={[styles.editBtn, { backgroundColor: `${colors.primary}15`, borderColor: `${colors.primary}40` }]}>
                  <Text style={[styles.editBtnText, { color: colors.primary }]}>✏️ Editar</Text>
                </Pressable>
                <Pressable onPress={() => handleDelete(habit)} style={[styles.deleteBtn, { backgroundColor: `${colors.accent}12`, borderColor: `${colors.accent}35` }]}>
                  <Text style={styles.deleteBtnText}>🗑️</Text>
                </Pressable>
              </View>
            </View>
          );
        })}
        <View style={{ height: 20 }} />
      </ScrollView>
    </View>
  );
}

const SENSOR_LABEL: Record<string, string> = {
  manual:        "👆 Manual",
  camera:        "📸 Cámara",
  accelerometer: "⚡ Acelerómetro",
  gyroscope:     "🧠 Giroscopio",
  location:      "📍 GPS",
};

const styles = StyleSheet.create({
  header:       { paddingHorizontal: 20, paddingBottom: 16, borderBottomWidth: 1 },
  headerAccent: { position: "absolute", top: 0, left: 0, right: 0, height: 3 },
  headerRow:    { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: 4 },
  title:        { fontSize: 22, fontWeight: "800" },
  subtitle:     { fontSize: 13 },
  addBtn:       { paddingHorizontal: 14, paddingVertical: 8, borderRadius: radii.full },
  addBtnText:   { color: "#fff", fontWeight: "600", fontSize: 13 },
  card:         { borderRadius: radii.lg, borderWidth: 1, padding: 14, ...shadows.card },
  cardTop:      { flexDirection: "row", alignItems: "center", gap: 12, marginBottom: 10 },
  emojiWrap:    { width: 48, height: 48, borderRadius: 12, alignItems: "center", justifyContent: "center" },
  habitName:    { fontSize: 17, fontWeight: "700" },
  habitSub:     { fontSize: 12, marginTop: 2 },
  todayRow:     { marginBottom: 8 },
  todayBadge:   { alignSelf: "flex-start", borderRadius: radii.full, paddingHorizontal: 10, paddingVertical: 4, borderWidth: 1 },
  todayDone:    { backgroundColor: "rgba(34,197,94,0.12)", borderColor: "rgba(34,197,94,0.35)" },
  todayPending: { backgroundColor: "rgba(108,99,255,0.08)", borderColor: "rgba(108,99,255,0.25)" },
  todayBadgeText: { fontSize: 12, fontWeight: "500" },
  description:  { fontSize: 13, marginBottom: 10 },
  actions:      { flexDirection: "row", gap: 8, marginTop: 4 },
  editBtn:      { flex: 1, borderRadius: radii.md, paddingVertical: 9, alignItems: "center", borderWidth: 1 },
  editBtnText:  { fontSize: 13, fontWeight: "500" },
  deleteBtn:    { borderRadius: radii.md, paddingHorizontal: 14, paddingVertical: 9, borderWidth: 1 },
  deleteBtnText:{ fontSize: 16 },
  empty:        { alignItems: "center", paddingVertical: 60 },
  emptyEmoji:   { fontSize: 56, marginBottom: 16 },
  emptyTitle:   { fontSize: 20, fontWeight: "700", marginBottom: 8 },
  emptySub:     { textAlign: "center", marginBottom: 24 },
  emptyBtn:     { paddingHorizontal: 24, paddingVertical: 12, borderRadius: radii.full },
  emptyBtnText: { color: "#fff", fontWeight: "600" },
});

